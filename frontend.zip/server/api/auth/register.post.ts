import { prisma } from '#server/utils/db'

export default defineEventHandler(async (event) => {
  await clearUserSession(event)

  const body = await readBody(event)

  const { username, password } = body

  const existingUser = await prisma.user.findUnique({
    where: {
      username,
    },
  })

  if (existingUser) {
    return createError({
      statusCode: 400,
      statusMessage: 'Username already exists',
    })
  }

  const user = {
    username,
    avatar: `https://mineskin.eu/helm/${username}/100`,
  }

  const hashedPassword = await hashPassword(password)

  await prisma.user.create({
    data: {
      ...user,
      password: hashedPassword,
    },
  })

  return await setUserSession(event, {
    user,
    loggedInAt: new Date(),
  })
})
