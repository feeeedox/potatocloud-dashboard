export default defineNuxtRouteMiddleware(async (to) => {
  const { loggedIn, fetch } = useUserSession()
  await fetch()

  const publicRoutes = ['/login', '/register']

  if (publicRoutes.includes(to.path)) {
    if (loggedIn.value) {
      return navigateTo('/')
    }
    return
  }

  if (!loggedIn.value) {
    return navigateTo('/login')
  }
})
