import type { CloudGroup, CloudPlayer, CloudService, CloudServiceStats } from '~/types/cloud'

export interface ScreenLogEvent {
  screenName: string
  line: string
}

export interface ScreenLogsResponse {
  screen: string
  logs: string[]
}

export interface ScreenListResponse {
  screens: Screen[]
}

export interface Screen {
  name: string
  lastUpdate: number
}

export interface WsGroupPayload {
  name: string
  platform: string
  platformVersion: string
  isProxy: boolean
  isFallback: boolean
  isStatic: boolean
  onlineServicesCount: number
  minOnlineCount: number
  maxOnlineCount: number
  onlinePlayerCount: number
  maxPlayers: number
  maxMemory: number
  startPercentage: number
  startPriority: number
}

export interface WsEventMap {
  'screen:logs:batch': ScreenLogDto
  'screen:list': ScreenListResponse
  'service_update': CloudService

  'player_update': CloudPlayer[]
  'groups_update': CloudGroup[]
  'group_details': CloudGroup
  'stats_update': CloudServiceStats
  'service_updates': CloudService[]
  'pong': null
  'error': string
}

export type WsEventType = keyof WsEventMap

export interface WsEnvelope<T extends WsEventType = WsEventType> {
  type: T
  data: WsEventMap[T]
}

export type WsStatus = 'connecting' | 'connected' | 'disconnected' | 'error'
